package entity;

public class UserExistsException extends Exception {
    private static final long serialVersionUID = 584737643480913385L;
}